package proyecto.final1;

public class ProyectoFinal {
    public static void main(String[] args) {
        Archivo archivo = new Archivo();
        archivo.setVisible(true);
        archivo.setLocationRelativeTo(null);
    }
    
}
