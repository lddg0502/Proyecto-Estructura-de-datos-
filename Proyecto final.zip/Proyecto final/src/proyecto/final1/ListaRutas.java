package proyecto.final1;

public class ListaRutas {
    private Rutas inicio;
    private int lenght;

    public ListaRutas() {
        this.inicio = null;
        this.lenght = 0;
    }
    
    // Agregar ruta al inicio de la lista rutas
    public void agregarRutaInicio(String nombreAlmacen1, String nombreAlmacen2, int distancia){
        Rutas ruta = new Rutas(nombreAlmacen1, nombreAlmacen2, distancia);
        if (estaVacio()){
            this.inicio = ruta;
        } else{
            ruta.setSiguiente(inicio);
            this.inicio = ruta;
        }
        this.lenght++;
    }
    
    // Agregar ruta al final de la lista rutas
    public void agregarRutaFinal(String nombreAlmacen1, String nombreAlmacen2, int distancia){
        Rutas ruta = new Rutas(nombreAlmacen1, nombreAlmacen2, distancia);
        if (estaVacio()){
            this.inicio = ruta;
        } else{
            Rutas pointer = getInicio();
            while (pointer.getSiguiente() != null){
                pointer = pointer.getSiguiente();
            }
            pointer.setSiguiente(ruta);
        }
        this.lenght++;
    }
    
    public boolean estaVacio(){
        return this.inicio == null;
    }

    public Rutas getInicio() {
        return inicio;
    }

    public void setInicio(Rutas inicio) {
        this.inicio = inicio;
    }

    public int getLenght() {
        return lenght;
    }

    public void setLenght(int lenght) {
        this.lenght = lenght;
    }
    
}
