package proyecto.final1;

public class ListaRutas {
    private Rutas inicio;
    private int lenght;
    
    /**
     * Constructor lista rutas
     */
    public ListaRutas() {
        this.inicio = null;
        this.lenght = 0;
    }
    
    /**
     * Se agrega una ruta al inicio de la lista rutas
     * @param nombreAlmacen1 Almacen origen
     * @param nombreAlmacen2 Almacen destino
     * @param distancia Longitud entre los almacenes
     */
    public void agregarRutaInicio(String nombreAlmacen1, String nombreAlmacen2, int distancia){
        Rutas ruta = new Rutas(nombreAlmacen1, nombreAlmacen2, distancia);
        if (estaVacio()){
            this.inicio = ruta;
        } else{
            ruta.setSiguiente(inicio);
            this.inicio = ruta;
        }
        this.lenght++;
    }
    
    /**
     Se agrega una ruta al final de la lista rutas
     * @param nombreAlmacen1 Almacen origen
     * @param nombreAlmacen2 Almacen destino
     * @param distancia Longitud entre los almacenes
     */
    public void agregarRutaFinal(String nombreAlmacen1, String nombreAlmacen2, int distancia){
        Rutas ruta = new Rutas(nombreAlmacen1, nombreAlmacen2, distancia);
        if (estaVacio()){
            this.inicio = ruta;
        } else{
            Rutas pointer = getInicio();
            while (pointer.getSiguiente() != null){
                pointer = pointer.getSiguiente();
            }
            pointer.setSiguiente(ruta);
        }
        this.lenght++;
    }
    
    /**
     * 
     * @param rutas Lista rutas que se va a imprimir
     * @return Retorna un string con la informacion de todas las rutas
     */
    public String imprimirRutas(ListaRutas rutas){
        Rutas nodoRuta = getInicio();
        String rutasInfo = "";
        while (nodoRuta != null){
            rutasInfo += nodoRuta.getOrigen() + ", " + nodoRuta.getDestino() + ", " + nodoRuta.getDistancia() + "\n";
            nodoRuta = nodoRuta.getSiguiente();
        }
        
        return rutasInfo;
    }
    
    public boolean estaVacio(){
        return this.inicio == null;
    }

    public Rutas getInicio() {
        return inicio;
    }

    public void setInicio(Rutas inicio) {
        this.inicio = inicio;
    }

    public int getLenght() {
        return lenght;
    }

    public void setLenght(int lenght) {
        this.lenght = lenght;
    }
    
}
