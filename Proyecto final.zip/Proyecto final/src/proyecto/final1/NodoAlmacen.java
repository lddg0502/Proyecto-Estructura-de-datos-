package proyecto.final1;

public class NodoAlmacen {
    private String nombre;
    private ListaProductos productos;
    private NodoAlmacen siguiente;
    private int id;
    
    public NodoAlmacen(String nombre, ListaProductos productos){
        this.nombre = nombre;
        this.productos = productos;
        this.siguiente = null;
        this.id = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ListaProductos getProductos() {
        return productos;
    }

    public void setProductos(ListaProductos productos) {
        this.productos = productos;
    }
    
    public NodoAlmacen getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoAlmacen siguiente) {
        this.siguiente = siguiente;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
