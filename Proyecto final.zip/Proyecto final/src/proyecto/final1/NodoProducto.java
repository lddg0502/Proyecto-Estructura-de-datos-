package proyecto.final1;

public class NodoProducto {
    private String nombreProducto;
    private int cantidadProducto;
    private NodoAlmacen almacen;
    private NodoProducto siguiente;

    public NodoProducto(String nombreProducto, int cantidadProducto) {
        this.nombreProducto = nombreProducto;
        this.cantidadProducto = cantidadProducto;
        this.almacen = null;
        this.siguiente = null;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public int getCantidadProducto() {
        return cantidadProducto;
    }

    public void setCantidadProducto(int cantidadProducto) {
        this.cantidadProducto = cantidadProducto;
    }

    public NodoAlmacen getAlmacen() {
        return almacen;
    }

    public void setAlmacen(NodoAlmacen almacen) {
        this.almacen = almacen;
    }
    
    public NodoProducto getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoProducto siguiente) {
        this.siguiente = siguiente;
    }
    
}
