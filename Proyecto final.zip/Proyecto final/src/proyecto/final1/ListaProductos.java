package proyecto.final1;

public class ListaProductos {
    private NodoProducto inicio;
    private int lenght;

    public ListaProductos() {
        this.inicio = null;
        this.lenght = 0;
    }
    
    // Agregar producto al inicio de la lista productos
    public void agregarProductoInicio(NodoProducto nodo){
        if (estaVacio()){
            this.inicio = nodo;
        } else{
            nodo.setSiguiente(inicio);
            this.inicio = nodo;
        }
        this.lenght++;
    }
    
    // Agregar producto al final de la lista productos
    public void agregarProductoFinal(NodoProducto nodo){
        if (estaVacio()){
            this.inicio = nodo;
        } else{
            NodoProducto pointer = getInicio();
            while (pointer.getSiguiente() != null){
                pointer = pointer.getSiguiente();
            }
            pointer.setSiguiente(nodo);
        }
        this.lenght++;
    }
    
    // Imprimir lista productos
    public String imprimirListaProductos(){
        NodoProducto nodo = getInicio();
        String info = "";
        while (nodo != null){
            info += "- " + nodo.getNombreProducto() + " (Cantidad: " + nodo.getCantidadProducto() + ")";
            info += "\n";
            nodo = nodo.getSiguiente();
        }
        return info;
    }
    
    public boolean estaVacio(){
        return this.inicio == null;
    }
    
    // --------------------- Getters y setters ------------------------

    public NodoProducto getInicio() {
        return inicio;
    }

    public void setInicio(NodoProducto inicio) {
        this.inicio = inicio;
    }

    public int getLenght() {
        return lenght;
    }

    public void setLenght(int lenght) {
        this.lenght = lenght;
    }    
}
