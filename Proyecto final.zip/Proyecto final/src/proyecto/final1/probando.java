package proyecto.final1;

public class probando {
    public static void main(String[] args) {
        Archivo ventana = new Archivo();
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
        ListaProductos productos = new ListaProductos();
        ListaProductos productos2 = new ListaProductos();
        ListaAlmacen almacen = new ListaAlmacen();
        
        NodoProducto nodo1 = new NodoProducto("Celular", 3);
        NodoProducto nodo2 = new NodoProducto("TV", 2);
        NodoProducto nodo3 = new NodoProducto("Nevera", 1);
        NodoProducto nodo4 = new NodoProducto("Mouse", 3);
        NodoProducto nodo5 = new NodoProducto("Celular", 5);
        NodoProducto nodo7 = new NodoProducto("Pantalla", 2);
        
        
        productos.agregarProductoInicio(nodo1);
        productos.agregarProductoInicio(nodo2);
        productos.agregarProductoInicio(nodo3);
        
        productos2.agregarProductoInicio(nodo4);
        productos2.agregarProductoInicio(nodo5);
        
        NodoAlmacen nodo6 = new NodoAlmacen("B", productos2);
        NodoAlmacen nodo = new NodoAlmacen("A", productos);
        nodo.getProductos().agregarProductoFinal(nodo7); 
        almacen.agregarAlmacenInicio(nodo);
        almacen.agregarAlmacenFinal(nodo6);
        
        System.out.println(productos.imprimirListaProductos());
        System.out.println(productos2.imprimirListaProductos());
        System.out.println(almacen.imprimirAlmacen("A"));
        System.out.println(almacen.imprimirAlmacen("B"));
        System.out.println(nodo.getId());
        System.out.println(nodo6.getId());
    }
}
