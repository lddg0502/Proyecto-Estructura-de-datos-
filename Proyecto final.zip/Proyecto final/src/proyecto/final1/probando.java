package proyecto.final1;

public class probando {    
    public void main(String[] args) {
        Archivo ventana = new Archivo();
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
               
    }
}
