package proyecto.final1;

public class ListaAlmacen {
    private NodoAlmacen inicio;
    private int lenght;
    
    /**
     * Constructor de la lista almacen
     */
    public ListaAlmacen() {
        this.inicio = null;
        this.lenght = 0;
    }
    
    /**
     * 
     * @param almacen Se pasa un nodo almacen para agregarlo al inicio de la lista almacenes
     */
    public void agregarAlmacenInicio(NodoAlmacen almacen){
        if (estaVacio()){
            setInicio(almacen);
        } else{
            almacen.setSiguiente(inicio);
            setInicio(almacen);
        }
        this.lenght++;
        almacen.setId(lenght);
    }
    
    /**
     * 
     * @param almacen Se pasa un nodo almacen para agregarlo al final de la lista almacenes
     */
    public void agregarAlmacenFinal(NodoAlmacen almacen){
        if (estaVacio()){
            setInicio(almacen);
        } else{
            NodoAlmacen pointer = getInicio();
            while (pointer.getSiguiente() != null){
                pointer = pointer.getSiguiente();
            }
            pointer.setSiguiente(almacen);
        }
        this.lenght++;
        almacen.setId(lenght);
    }
    
    /**
     * 
     * @param nombre Se recibe el nombre del almacen a imprimir
     * @return Retorna un string con el nombre del almacen y los productos que contiene
     */
    public String imprimirAlmacen(String nombre){
        NodoAlmacen nodo = getInicio();
        while (!nodo.getNombre().equals(nombre) && nodo.getSiguiente() != null){
            nodo = nodo.getSiguiente();
        }
        if (nodo.getNombre().equals(nombre)){
            String info = "";
            info += "Almacen " + nodo.getNombre() + "\n" + "Productos: " + nodo.getProductos().imprimirListaProductos();
            
            return info;
        }
        return "No se ha encontrado el almacen";
    }
    
    /**
     * 
     * @param almacenes Se pasa la lista almacenes para imprimir todos los almacenes
     * @return Retorna un string con toda la informacion de los almacenes
     */
    public String imprimirAlmacenes(ListaAlmacen almacenes){
        NodoAlmacen nodo = getInicio();
        String info = "";
        while (nodo != null){
            info+= "Almacen " + nodo.getNombre() + "\n" + "Productos: " + nodo.getProductos().imprimirListaProductos() + "\n";
            nodo = nodo.getSiguiente();
        }
        return info;
    }
    
    /**
     * 
     * @param nombreAlmacen Nombre del almacen a ser comparado
     * @param almacen Lista de almacenes
     * @return Retorna un booleano que es true si el nombre esta en la lista almacen o false si no esta en la lista
     */
    public boolean compararNombreAlmacen(String nombreAlmacen, ListaAlmacen almacen){
        NodoAlmacen nodo = almacen.getInicio();
        boolean esIgual = false;
        while (!esIgual){
            if (nodo.getNombre().equals(nombreAlmacen)){
                return true;
            } else if (nodo.getSiguiente() != null){
                nodo = nodo.getSiguiente();
            } else{
                return false;
            }
        }
        return false;
    }
    
    /**
     * Se buscan todos los almacenes que contengan el nombre del producto pasado por parametro
     * @param nombreProducto 
     * @return Retorna un string con los nombres de los almacenes que contengan el producto
     */
    public String buscarAlmacenPorProducto(String nombreProducto){
        int contador = 0;
        boolean encontrado = false;
        String cadena = "";
        NodoAlmacen nodo = getInicio();
        while (contador < getLenght()){
            int contador2 = 0;
            NodoProducto producto = nodo.getProductos().getInicio();
            while (contador2 < nodo.getProductos().getLenght()){
                if (producto.getNombreProducto().equals(nombreProducto)){
                    encontrado = true;
                    cadena += nodo.getNombre() + " ";
                    producto = producto.getSiguiente();
                    contador2++;
                } else{
                    producto = producto.getSiguiente();
                    contador2++;
                }
            }
            nodo = nodo.getSiguiente();
            contador++;
        }
        return cadena;
    }
    
    public boolean estaVacio(){
        return this.inicio == null;
    }

    public NodoAlmacen getInicio() {
        return inicio;
    }

    public void setInicio(NodoAlmacen inicio) {
        this.inicio = inicio;
    }

    public int getLenght() {
        return lenght;
    }

    public void setLenght(int lenght) {
        this.lenght = lenght;
    }  
}
