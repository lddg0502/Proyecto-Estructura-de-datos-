package proyecto.final1;

public class ListaAlmacen {
    private Almacen almacen;
    private NodoAlmacen inicio;
    private int lenght;

    public ListaAlmacen() {
        this.inicio = null;
        this.almacen = null;
        this.lenght = 0;
    }

    public int getLenght() {
        return lenght;
    }
    

    public NodoAlmacen getInicio() {
        return inicio;
    }

    public void setInicio(NodoAlmacen inicio) {
        this.inicio = inicio;
    }

    public Almacen getAlmacen() {
        return almacen;
    }

    public void setAlmacen(Almacen almacen) {
        this.almacen = almacen;
    }
    
    public void agregarInicio(Almacen almacen){
        NodoAlmacen nodo = new NodoAlmacen(almacen);
        if (estaVacio()){
           this.inicio = nodo;
        } else{
            nodo.setSiguiente(this.inicio);
            this.inicio = nodo;
        }
        this.lenght++;
    }
    public Almacen obtenerAlmacenLugar(int pos){
        if (estaVacio()) {
            return null;
        } else {
            NodoAlmacen pointer = getInicio();
            int cont = 0;
            while (cont < pos && pointer.getSiguiente() != null) {
                pointer = pointer.getSiguiente();
                cont++;
            }
            if (cont == pos) {
                return pointer.getAlmacen();
            } else {
                return null;
            }
        }
    }
    public Almacen obtenerAlmacenNombre(String name){
        if (estaVacio()){
            return null;
        }else{
            NodoAlmacen pointer = getInicio();
            int cont = 0;
            int pos = this.lenght; 
            while(pointer.getAlmacen().getName() == name){
                pointer = pointer.getSiguiente();
                if (pointer.getSiguiente() == null){
                    System.out.println("No se encontro el Almacen"+name);
                    return null;
                }
            }
            return pointer.getAlmacen();
        }      
    }
    public boolean estaVacio(){
        return this.inicio == null;
    }
    public Productos obtenerProductoAlamcen(Almacen almacen, String name){
        Productos prod = almacen.getProductos().obtenerProducto(name);
        return prod;
    }
    
    public Almacen obtenerAlmacenProducto (String nameprod){
        
        for (int i = 0; i < this.getLenght();i++){
            if (obtenerAlmacenLugar(i).getProductos().obtenerProducto(nameprod)!=null){
                return obtenerAlmacenLugar(i);
            }    
        }
        return null;
    }
    public void actualizarProducto(String nameprod, int cant){  
        if (obtenerAlmacenProducto(nameprod)!= null){
            obtenerProductoAlamcen(obtenerAlmacenProducto(nameprod), nameprod).setCantidadProducto(cant);    
        }
    }    
}
