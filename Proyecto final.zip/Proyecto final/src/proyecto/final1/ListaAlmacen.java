package proyecto.final1;

public class ListaAlmacen {
    private NodoAlmacen inicio;
    private int lenght;

    public ListaAlmacen() {
        this.inicio = null;
        this.lenght = 0;
    }
    
    // Agregar almacen al inicio de la lista almacenes
    public void agregarAlmacenInicio(NodoAlmacen almacen){
        if (estaVacio()){
            setInicio(almacen);
        } else{
            almacen.setSiguiente(inicio);
            setInicio(almacen);
        }
        this.lenght++;
        almacen.setId(lenght);
    }
    
    // Agregar almacen al final de la lista almacen
    public void agregarAlmacenFinal(NodoAlmacen almacen){
        if (estaVacio()){
            setInicio(almacen);
        } else{
            NodoAlmacen pointer = getInicio();
            while (pointer.getSiguiente() != null){
                pointer = pointer.getSiguiente();
            }
            pointer.setSiguiente(almacen);
        }
        this.lenght++;
        almacen.setId(lenght);
    }
    
    // Metodo que recibe como parametro el nombre del almacen a imprimir y los productos que contiene
    public String imprimirAlmacen(String nombre){
        NodoAlmacen nodo = getInicio();
        while (!nodo.getNombre().equals(nombre) && nodo.getSiguiente() != null){
            nodo = nodo.getSiguiente();
        }
        if (nodo.getNombre().equals(nombre)){
            String info = "";
            info += "Almacen " + nodo.getNombre() + "\n" + "Productos: " + nodo.getProductos().imprimirListaProductos();
            
            return info;
        }
        return "No se ha encontrado el almacen";
    }
    
    // Verificar que el nombre del nuevo almacen no este repetido
    public boolean compararNombreAlmacen(String nombreAlmacen, ListaAlmacen almacen){
        NodoAlmacen nodo = almacen.getInicio();
        boolean esIgual = false;
        while (!esIgual){
            if (nodo.getNombre().equals(nombreAlmacen)){
                return true;
            } else{
                nodo = nodo.getSiguiente();
            }
        }
        return false;
    }
    
    public boolean estaVacio(){
        return this.inicio == null;
    }

    public NodoAlmacen getInicio() {
        return inicio;
    }

    public void setInicio(NodoAlmacen inicio) {
        this.inicio = inicio;
    }

    public int getLenght() {
        return lenght;
    }

    public void setLenght(int lenght) {
        this.lenght = lenght;
    }  
}
