package proyecto.final1;

public class Vertice {
    protected String nombre;
    protected int numVertice;
    
    public Vertice(String x){
        nombre = x;
        numVertice = -1;
    }
 
    public boolean equals(Vertice n){
        return nombre.equals(n.nombre);
    }
    
    public void asignarVertice(int n){
        numVertice = n;
    }
    
    @Override
    public String toString(){
        return nombre + " (" + numVertice + ")";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumVertice() {
        return numVertice;
    }

    public void setNumVertice(int numVertice) {
        this.numVertice = numVertice;
    }
    
}
