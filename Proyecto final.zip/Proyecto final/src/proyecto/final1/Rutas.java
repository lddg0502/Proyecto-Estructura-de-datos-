package proyecto.final1;

public class Rutas {
    private String origen;
    private String destino;
    private int distancia;
    private Rutas siguiente;

    public Rutas(String origen, String destino, int distancia) {
        this.origen = origen;
        this.destino = destino;
        this.distancia = distancia;
        this.siguiente = null;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public int getDistancia() {
        return distancia;
    }

    public void setDistancia(int distancia) {
        this.distancia = distancia;
    }

    public Rutas getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Rutas siguiente) {
        this.siguiente = siguiente;
    }    
}
