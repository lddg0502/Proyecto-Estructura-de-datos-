package proyecto.final1;

import javax.swing.JOptionPane;

public class Grafo {
    private int numVerts;
    private Vertice [] verts;
    private int [][] matAd;

    /**
     * Constructor grafo
     * @param max
     */
    public Grafo(int max){
        matAd = new int[max][max];
        verts = new Vertice[max];
        for (int i = 0; i < max; i++){
            for (int j = 0; j < max; j++){
                matAd[i][j] = 0;
            }      
        }
        numVerts = 0;
    }
        
    /**
     * 
     * @param almacenes Lista almacenes
     * @param rutas Lista rutas
     * @param grafo
     * @return Retorna el grafo ya creado
     */
    public Grafo crearGrafo(ListaAlmacen almacenes, ListaRutas rutas, Grafo grafo){
        if (!almacenes.estaVacio()){
            NodoAlmacen almacen = almacenes.getInicio();
            while (almacen != null){
                Vertice vertice = new Vertice(almacen.getNombre());
                grafo.nuevoVertice(vertice);
                almacen = almacen.getSiguiente();
            }           
        }

        if (!rutas.estaVacio()){
            Rutas ruta = rutas.getInicio();
            Vertice[] vertices = grafo.vertices();
            while (ruta != null) { 
                Vertice tempOrigen = new Vertice(ruta.getOrigen());
                Vertice tempDestino = new Vertice(ruta.getDestino());
                Vertice verticeOrigen = vertices[grafo.numVertice(tempOrigen)];
                Vertice verticeDestino = vertices[grafo.numVertice(tempDestino)];
                grafo.nuevoArco(verticeOrigen, verticeDestino, ruta.getDistancia());
                ruta = ruta.getSiguiente();
            }
        
        }        
        return grafo;
    }
        
    /**
     * 
     * @param vertice 
     */
    public void nuevoVertice(Vertice vertice){
        boolean esta = numVertice(vertice) >= 0;
        if(!esta){
            vertice.asignarVertice(numVerts);
            verts[numVerts++] = vertice;
        }
    }
    
    /**
     * 
     * @param vertice
     * @return 
     */
    public int numVertice(Vertice vertice){
        boolean encontrado = false;
        int i = 0;
        for(;(i < numVerts) && !encontrado;){
            encontrado = verts[i].equals(vertice);
            if(!encontrado) i++;
        }
        if (encontrado){
            return 0;
        } else{
            return -1;
        }
    }
    
    
    /**
     * 
     * @param a Vertice origen
     * @param b Vertice destino
     * @param distancia Longitud del arco
     */
    public void nuevoArco(Vertice a, Vertice b, int distancia){  
        int[][] matAux = getMatAd();
        int va, vb;
        va = a.getNumVertice();
        vb = b.getNumVertice();
        matAux[va][vb] = distancia;
    }
    
    public Vertice[] vertices(){
        return verts;
    }
    
    /**
     * 
     * @param a Vertice origen
     * @param b Vertice destino
     * @return Retorna la distancia entre dos vertices
     */
    public int pesoArco(Vertice a, Vertice b){
        int va, vb;
        va = a.getNumVertice();
        vb = b.getNumVertice();
        return matAd[va][vb];
    }
    
    /**
     * 
     * @param grafo Se pasa el grafo para imprimir su matriz de adyacencia
     */
    public void imprimirMatriz(Grafo grafo){
        int[][] matAux = grafo.getMatAd();
        for (int i=0; i<matAux.length; i++){
            for (int j=0; j<matAux[i].length; j++){
                System.out.print(matAux[i][j] + "  ");
            }
            System.out.println("");
        }
    }
    
    /**
     * 
     * @param a Vertice origen
     * @param b Vertice destino
     * @return Retorna un booleano que indica si dos vertices son adyacentes
     */    
    public boolean verticeAdyacente(Vertice a, Vertice b){
        int va, vb;
        va = a.getNumVertice();
        vb = b.getNumVertice();
        if (va < 0 || vb < 0){
            JOptionPane.showMessageDialog(null, "El vertice no existe");
        }
        return matAd[va][vb] != 0;
    }
    
    /**
     * Se agrega un almacen al grafo
     * @param almacen 
     */
    public void agregarAlmacen(ListaAlmacen almacen){
        boolean continuar = true;
        String nombreAlmacen = "";
        String nombreProducto = "";
        int cantidadProducto = 0;
        
        JOptionPane.showMessageDialog(null, "A continuacion se le pediran los datos del almacen a ingresar");
        
        do{
           nombreAlmacen = JOptionPane.showInputDialog("Ingrese el nombre del almacen (No ingrese nombres repetidos)"); 
        } while (almacen.compararNombreAlmacen(nombreAlmacen, almacen));
        
        while (continuar){
            ListaProductos productos = new ListaProductos();
            String respuesta = "y";
            while (respuesta.equals("y")){
                    nombreProducto = JOptionPane.showInputDialog("Ingrese el nombre del producto que se agregara al almacen");
                try{
                    cantidadProducto = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad del nuevo producto"));
                } catch (Exception e){
                    JOptionPane.showMessageDialog(null, "Ingrese una cantidad valida");
                    cantidadProducto = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad del nuevo producto"));
                }
                
                NodoProducto nodo = new NodoProducto(nombreProducto, cantidadProducto);
                productos.agregarProductoInicio(nodo);
                JOptionPane.showMessageDialog(null, "Producto agregado satisfactoriamente");
                
                respuesta = "";
                
                do{
                    respuesta = JOptionPane.showInputDialog("Desea agregar un nuevo producto? ('y' para si, 'n' para no)");
                } while (!"y".equals(respuesta) && !"n".equals(respuesta));
     
                if ("n".equals(respuesta)){
                    NodoAlmacen nodoAlmacen = new NodoAlmacen(nombreAlmacen, productos);
                    almacen.agregarAlmacenFinal(nodoAlmacen);
                    JOptionPane.showMessageDialog(null, "Se ha creado el almacen exitosamente");
                    this.nuevoVertice(new Vertice(nodoAlmacen.getNombre()));
                    continuar = false;
                } 
            }            
        }
    }
        
    public int[][] getMatAd() {
        return matAd;
    }

    public void setMatAd(int[][] matAd) {
        this.matAd = matAd;
    }
    
    public int numeroDeVertices(){
        return this.numVerts;
    }
    
}
