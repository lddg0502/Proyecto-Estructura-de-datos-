package proyecto.final1;

import javax.swing.JOptionPane;

public class Grafo {
    protected int numVertices;
    protected Vertice [] verts;
    protected int [][] matAd;
    protected int peso;
    
    public Grafo(int max){
        matAd = new int[max][max];
        verts = new Vertice[max];
        for (int i = 0; i < max; i++){
            for (int j = 0; i < max; i++){
                matAd[i][j] = 0;
                numVertices = 0;
            }      
        }           
    }
    
    // Metodo para crear un nuevo grafo
    public Grafo crearGrafo(ListaAlmacen almacenes, ListaRutas rutas){
        Grafo grafo = new Grafo(999);
        
        if (!almacenes.estaVacio()){
            NodoAlmacen almacen = almacenes.getInicio();
            while (almacen != null){
                grafo.nuevoVertice(new Vertice(almacen.getNombre()));
                almacen.getSiguiente();
            }           
        }

        if (!rutas.estaVacio()){
            Rutas ruta = rutas.getInicio();
            Vertice[] vertices = grafo.vertices();
            while (ruta != null) {                
                Vertice tempOrigen = new Vertice(ruta.getOrigen());
                Vertice tempDestino = new Vertice(ruta.getDestino());
                Vertice verticeOrigen = vertices[grafo.numVertice(tempOrigen)];
                Vertice verticeDestino = vertices[grafo.numVertice(tempDestino)];
                grafo.nuevoArco(verticeOrigen, verticeDestino, ruta.getDistancia());
                ruta = ruta.getSiguiente();
            }
        
        }
        return grafo;
    }
    
    // Metodo para incrementar el numero de vertices
    public void nuevoVertice(Vertice vertice){
        boolean esta = numVertice(vertice) >= 0;
        if(!esta){
            vertice.asignarVertice(numVertices);
            verts[numVertices++] = vertice;
        }
    }
    
    public int numVertice(Vertice vertice){
        boolean encontrado = false;
        int i = 0;
        for(;(i < numVertices) && !encontrado;){
            encontrado = verts[i].equals(vertice);
            if(!encontrado) i++;
        }
        return (i < numVertices)? i : -1;
    }
    
    // Metodo para crear un nuevo camino entre dos vertices
    public void nuevoArco(Vertice a, Vertice b, int distancia){
        int va, vb;
        va = numVertice(a);
        vb = numVertice(b);
        matAd[va][vb] = distancia;
    }
    
    // Metodo para devolver los vertices creados
    public Vertice[] vertices(){
        return verts;
    }
    
    // Metodo que devuelve la distancia entre dos vertices
    public int pesoArco(Vertice a, Vertice b){
        int va, vb;
        va = numVertice(a);
        vb = numVertice(b);
        return matAd[va][vb];
    }
    
    // Metodo para agregar un almacen al grafo
    public void agregarAlmacen(ListaAlmacen almacen){
        boolean continuar = true;
        String nombreAlmacen = "";
        String nombreProducto = "";
        int cantidadProducto = 0;
        
        JOptionPane.showMessageDialog(null, "A continuacion se le pediran los datos del almacen a ingresar");
        do{
           nombreAlmacen = JOptionPane.showInputDialog("Ingrese el nombre del almacen (No ingrese nombres repetidos)"); 
        } while (almacen.compararNombreAlmacen(nombreAlmacen, almacen));
        while (continuar){
            String respuesta = "";
            nombreProducto = JOptionPane.showInputDialog("Ingrese el nombre del producto que se agregara al almacen");
            try{
                cantidadProducto = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad del nuevo producto"));
            } catch (Exception e){
                JOptionPane.showMessageDialog(null, "Ingrese una cantidad valida");
            }
            ListaProductos productos = new ListaProductos();
            NodoProducto nodo = new NodoProducto(nombreProducto, cantidadProducto);
            productos.agregarProductoInicio(nodo);
            JOptionPane.showMessageDialog(null, "Producto agregado satisfactoriamente");
            while (!"y".equals(respuesta) || !"n".equals(respuesta)){
                respuesta = JOptionPane.showInputDialog("Desea agregar un nuevo producto?");
            }
            if ("n".equals(respuesta)){
                continuar = false;
                NodoAlmacen nodoAlmacen = new NodoAlmacen(nombreAlmacen, productos);
                almacen.agregarAlmacenFinal(nodoAlmacen);
                this.numVertices++;
            }
        }
    }
    
}
