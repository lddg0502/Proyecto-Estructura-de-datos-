package proyecto.final1;

import javax.swing.JOptionPane;

public class Grafo {
    protected int numVertices;
    protected Vertice [] verts;
    protected int [][] matAd;
    protected int peso;
    
    public Grafo(int max){
        matAd = new int[max][max];
        verts = new Vertice[max];
        for (int i = 0; i < max; i++){
            for (int j = 0; i < max; i++){
                matAd[i][j] = 0;
                numVertices = 0;
            }      
        }           
    }
    
    // Agregar un almacen al grafo
    public void agregarAlmacen(ListaAlmacen almacen){
        boolean continuar = true;
        String nombreAlmacen = "";
        String nombreProducto = "";
        int cantidadProducto = 0;
        
        JOptionPane.showMessageDialog(null, "A continuacion se le pediran los datos del almacen a ingresar");
        do{
           nombreAlmacen = JOptionPane.showInputDialog("Ingrese el nombre del almacen (No ingrese nombre repetidos)"); 
        } while (almacen.compararNombreAlmacen(nombreAlmacen, almacen));
        while (continuar){
            String respuesta = "";
            nombreProducto = JOptionPane.showInputDialog("Ingrese el nombre del producto que se agregara al almacen");
            try{
                cantidadProducto = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad del nuevo producto"));
            } catch (Exception e){
                JOptionPane.showMessageDialog(null, "Ingrese una cantidad valida");
            }
            ListaProductos productos = new ListaProductos();
            NodoProducto nodo = new NodoProducto(nombreProducto, cantidadProducto);
            productos.agregarProductoInicio(nodo);
            JOptionPane.showMessageDialog(null, "Producto agregado satisfactoriamente");
            while (!"y".equals(respuesta) || !"n".equals(respuesta)){
                respuesta = JOptionPane.showInputDialog("Desea agregar un nuevo producto?");
            }
            if ("n".equals(respuesta)){
                continuar = false;
                NodoAlmacen nodoAlmacen = new NodoAlmacen(nombreAlmacen, productos);
                almacen.agregarAlmacenFinal(nodoAlmacen);
                this.numVertices++;
            }
        }
    }
    
    // Agregar una ruta entre dos almacenes
    public void agregarRutaAlmacenes(String nombreVertice1, String nombreVertice2, int longitudRuta){
        Rutas ruta = new Rutas(nombreVertice1, nombreVertice2, longitudRuta);
        
    }
}
