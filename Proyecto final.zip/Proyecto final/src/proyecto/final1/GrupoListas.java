package proyecto.final1;

public class GrupoListas {
    private ListaAlmacen almacenes;
    private ListaRutas rutas;
    
    public GrupoListas(ListaAlmacen almacenes, ListaRutas rutas){
        this.almacenes = almacenes;
        this.rutas = rutas;
    }

    public ListaAlmacen getAlmacenes() {
        return almacenes;
    }

    public void setAlmacenes(ListaAlmacen almacenes) {
        this.almacenes = almacenes;
    }

    public ListaRutas getRutas() {
        return rutas;
    }

    public void setRutas(ListaRutas rutas) {
        this.rutas = rutas;
    }
    
}
