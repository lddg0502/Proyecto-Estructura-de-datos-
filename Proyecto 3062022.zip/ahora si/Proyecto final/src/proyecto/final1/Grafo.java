package proyecto.final1;

import javax.swing.JOptionPane;

public class Grafo {
    protected int numVertices;
    protected Vertice [] verts;
    protected int [][] matAd;
    protected int peso;
    protected int max=5;
    
    public Grafo(){
        matAd = new int[max][max];
        verts = new Vertice[max];
        for (int i = 0; i < max; i++){
            for (int j = 0; j < max; j++){
                matAd[i][j] = 0;
                numVertices = 0;
            }      
        }
    }
        
    // Metodo para crear un nuevo grafo
    public Grafo crearGrafo(ListaAlmacen almacenes, ListaRutas rutas){
        Grafo grafo = new Grafo();
        if (!almacenes.estaVacio()){
            NodoAlmacen almacen = almacenes.getInicio();
            while (almacen != null){
                grafo.nuevoVertice(almacen.getNombre());
                almacen = almacen.getSiguiente();
            }           
        }

        if (!rutas.estaVacio()){
            Rutas ruta = rutas.getInicio();
            Vertice[] vertices = grafo.vertices();
            while (ruta != null) {                
                Vertice verticeOrigen = vertices[grafo.numVertice(ruta.getOrigen())];
                Vertice verticeDestino = vertices[grafo.numVertice(ruta.getDestino())];
                int[][] matAux = grafo.nuevoArco(verticeOrigen, verticeDestino, ruta.getDistancia());
                ruta = ruta.getSiguiente();
                setMatAd(matAux);
            }
        
        }        
        return grafo;
    }
    
    // Metodo para incrementar el numero de vertices
    public void nuevoVertice(String nombre){
        boolean esta = numVertice(nombre) >= 0;
        if(!esta){
            Vertice vertice = new Vertice(nombre);
            vertice.asignarVertice(numVertices);
            verts[numVertices++] = vertice;
        }
    }
    
    public int numVertice(String nombre){
        Vertice vertice = new Vertice(nombre);
        boolean encontrado = false;
        int i = 0;
        for(;(i < numVertices) && !encontrado;){
            encontrado = verts[i].equals(vertice);
            if(!encontrado) i++;
        }
        return (i < numVertices)? i : -1;
    }
    
    // Metodo para crear un nuevo camino entre dos vertices
    public int[][] nuevoArco(Vertice a, Vertice b, int distancia){  
        int[][] matAux = getMatAd();
        int va, vb;
        va = a.getNumVertice();
        vb = b.getNumVertice();
        matAux[va][vb] = distancia;
        return matAux;
    }
    
    // Metodo para devolver los vertices creados
    public Vertice[] vertices(){
        return verts;
    }
    
    // Metodo que devuelve la distancia entre dos vertices
    public int pesoArco(Vertice a, Vertice b){
        int va, vb;
        va = a.getNumVertice();
        vb = b.getNumVertice();
        return matAd[va][vb];
    }
    
    public void imprimirMatriz(Grafo grafo){
        int[][] matAux = grafo.getMatAd();
        for (int i=0; i<matAux.length; i++){
            for (int j=0; j<matAux[i].length; j++){
                System.out.print(matAux[i][j] + "  ");
            }
            System.out.println("");
        }
    }
    
    // Metodo para verificar si dos vertices tienen un camino entre ellos
    public boolean verticeAdyacente(Vertice a, Vertice b){
        int va, vb;
        va = a.getNumVertice();
        vb = b.getNumVertice();
        if (va < 0 || vb < 0){
            JOptionPane.showMessageDialog(null, "El vertice no existe");
        }
        return matAd[va][vb] != 0;
    }
    
    // Metodo para agregar un almacen al grafo
    public void agregarAlmacen(ListaAlmacen almacen){
        boolean continuar = true;
        String nombreAlmacen = "";
        String nombreProducto = "";
        int cantidadProducto = 0;
        
        JOptionPane.showMessageDialog(null, "A continuacion se le pediran los datos del almacen a ingresar");
        do{
           nombreAlmacen = JOptionPane.showInputDialog("Ingrese el nombre del almacen (No ingrese nombres repetidos)"); 
        } while (almacen.compararNombreAlmacen(nombreAlmacen, almacen));
        while (continuar){
            String respuesta = "";
            nombreProducto = JOptionPane.showInputDialog("Ingrese el nombre del producto que se agregara al almacen");
            try{
                cantidadProducto = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad del nuevo producto"));
            } catch (Exception e){
                JOptionPane.showMessageDialog(null, "Ingrese una cantidad valida");
            }
            ListaProductos productos = new ListaProductos();
            NodoProducto nodo = new NodoProducto(nombreProducto, cantidadProducto);
            productos.agregarProductoInicio(nodo);
            JOptionPane.showMessageDialog(null, "Producto agregado satisfactoriamente");
            while (!"y".equals(respuesta) || !"n".equals(respuesta)){
                respuesta = JOptionPane.showInputDialog("Desea agregar un nuevo producto?");
            }
            if ("n".equals(respuesta)){
                continuar = false;
                NodoAlmacen nodoAlmacen = new NodoAlmacen(nombreAlmacen, productos);
                almacen.agregarAlmacenFinal(nodoAlmacen);
                this.numVertices++;
            }
        }
    }
    
    public String recorridoPorAnchura(String origen){
        ColaLista cola = new ColaLista();
        String cadena = "";
        Vertice inicio = new Vertice(origen);
        int inicioId = inicio.getNumVertice();
        
        Vertice aux;
        
        if (inicio != null){
            cola.encolar(inicio);
            inicio.visitado = true;
            while (!cola.estaVacio()){
                
            }
        }
        return cadena;
    }
    
    public int[][] getMatAd() {
        return matAd;
    }

    public void setMatAd(int[][] matAd) {
        this.matAd = matAd;
    }

    public int getNumVertices() {
        return numVertices;
    }

    public void setNumVertices(int numVertices) {
        this.numVertices = numVertices;
    }
    
    
}
