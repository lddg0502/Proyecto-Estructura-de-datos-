package proyecto.final1;

public class ListaAlmacen {
    private NodoAlmacen inicio;
    private int lenght;

    public ListaAlmacen() {
        this.inicio = null;
        this.lenght = 0;
    }
    
    // Agregar almacen al inicio de la lista almacenes
    public void agregarAlmacenInicio(NodoAlmacen almacen){
        if (estaVacio()){
            setInicio(almacen);
        } else{
            almacen.setSiguiente(inicio);
            setInicio(almacen);
        }
        this.lenght++;
        almacen.setId(lenght);
    }
    
    // Agregar almacen al final de la lista almacen
    public void agregarAlmacenFinal(NodoAlmacen almacen){
        if (estaVacio()){
            setInicio(almacen);
        } else{
            NodoAlmacen pointer = getInicio();
            while (pointer.getSiguiente() != null){
                pointer = pointer.getSiguiente();
            }
            pointer.setSiguiente(almacen);
        }
        this.lenght++;
        almacen.setId(lenght);
    }
    
    // Metodo que recibe como parametro el nombre del almacen a imprimir y los productos que contiene
    public String imprimirAlmacen(String nombre){
        NodoAlmacen nodo = getInicio();
        while (!nodo.getNombre().equals(nombre) && nodo.getSiguiente() != null){
            nodo = nodo.getSiguiente();
        }
        if (nodo.getNombre().equals(nombre)){
            String info = "";
            info += "Almacen " + nodo.getNombre() + "\n" + "Productos: " + nodo.getProductos().imprimirListaProductos();
            
            return info;
        }
        return "No se ha encontrado el almacen";
    }
    
    // Metodo que imprime todos los almacenes dentro de la lista almacenes
    public String imprimirAlmacenes(ListaAlmacen almacenes){
        NodoAlmacen nodo = getInicio();
        String info = "";
        while (nodo != null){
            info+= "Almacen " + nodo.getNombre() + "\n" + "Productos: " + nodo.getProductos().imprimirListaProductos() + "\n";
            nodo = nodo.getSiguiente();
        }
        return info;
    }
    
    // Verificar que el nombre del nuevo almacen no este repetido
    public boolean compararNombreAlmacen(String nombreAlmacen, ListaAlmacen almacen){
        NodoAlmacen nodo = almacen.getInicio();
        boolean esIgual = false;
        while (!esIgual){
            if (nodo.getNombre().equals(nombreAlmacen)){
                return true;
            } else{
                nodo = nodo.getSiguiente();
            }
        }
        return false;
    }
    
    public String buscarAlmacenPorProducto(String nombreProducto){
        int contador = 0;
        boolean encontrado = false;
        String cadena = "";
        NodoAlmacen nodo = getInicio();
        while (contador < getLenght()){
            int contador2 = 0;
            NodoProducto producto = nodo.getProductos().getInicio();
            while (contador2 < nodo.getProductos().getLenght()){
                if (producto.getNombreProducto().equals(nombreProducto)){
                    encontrado = true;
                    cadena += nodo.getNombre() + " ";
                    producto = producto.getSiguiente();
                    contador2++;
                } else{
                    producto = producto.getSiguiente();
                    contador2++;
                }
            }
            nodo = nodo.getSiguiente();
            contador++;
        }
        return cadena;
    }
    
    public boolean estaVacio(){
        return this.inicio == null;
    }

    public NodoAlmacen getInicio() {
        return inicio;
    }

    public void setInicio(NodoAlmacen inicio) {
        this.inicio = inicio;
    }

    public int getLenght() {
        return lenght;
    }

    public void setLenght(int lenght) {
        this.lenght = lenght;
    }  
}
