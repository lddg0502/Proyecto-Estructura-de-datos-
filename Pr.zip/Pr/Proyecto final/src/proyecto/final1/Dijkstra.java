package proyecto.final1;

public class Dijkstra {
    protected int[][] matrizPeso;
    protected int[] ultimo;
    protected int[] d;
    protected boolean[] F;
    protected int origen, numVertices;
    
    public Dijkstra(int[][] matrizPeso, int numVertices, int origen){
        
        this.numVertices = numVertices;
        this.matrizPeso = matrizPeso;
        this.origen = origen;
        this.ultimo = new int[numVertices];
        this.F = new boolean[numVertices];
        this.d = new int[numVertices];
        
    }
    
    public void caminoMinimo(){
        
        for(int i = 0; i<numVertices; i++){
            
            F[i] = false;
            if (matrizPeso[origen][i] == 0){
                d[i] = 999999999;
            }else{
                d[i] = matrizPeso[origen][i];
                ultimo[i] = origen;
            }
        }
        
        F[origen] = true;
        d[origen] = 0;
        
        for(int i = 1; i < numVertices; i++){
            
            int verticeNoMarcado = minimo();
            F[verticeNoMarcado] = true;
            
            for(int w = 1; w < numVertices; w++){
                
                if(!F[w]){
                    
                    if((d[verticeNoMarcado] + matrizPeso[verticeNoMarcado][w]) < d[w]){
                        
                        d[w] = d[verticeNoMarcado] + matrizPeso[verticeNoMarcado][w];
                        ultimo[w] = verticeNoMarcado;
                        
                    }
                    
                }
                
            }
        }
        
        int[] ultimoAux = new int[numVertices];
        int contador = 0;
        int aux = -1;
        
        for(int i = 0; i<ultimo.length; i++){
            
            if(i == 0){
                aux = ultimo[i];
                ultimoAux[contador] = aux;
                contador++;
            }else{
                
                if(aux != ultimo[i]){
                    aux = ultimo[i];
                    ultimoAux[contador] = aux;
                    contador++;
                }
                
            }
            
        }
        
        for (int i = contador; i<ultimoAux.length; i++){
            
            ultimoAux[i] = -1;
            
        }
     
    }
    public int minimo(){
        
        int max = 999999999;
        int verticeNoMarcado = 1;
        for(int i = 0; i<numVertices;i++){
            
            if(!F[i] && (d[i]<=max)){
                
                max = d[i];
                verticeNoMarcado = i;
                
            }
        }
        
        return verticeNoMarcado;
}
}