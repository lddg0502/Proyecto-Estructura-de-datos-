package proyecto.final1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class CargarInformacion {
    public GrupoListas leerTxt(){
        ListaAlmacen almacenes = new ListaAlmacen();
        ListaRutas rutas = new ListaRutas();
        String line;
        String txt = "";
        
        JFileChooser archivo = new JFileChooser();
        int seleccion = archivo.showOpenDialog(null);
        if (seleccion == JFileChooser.APPROVE_OPTION){
            String nameArchivo = archivo.getSelectedFile().getAbsolutePath();
            File archivoTxt = new File(nameArchivo);
                
            try{
                FileReader fr = new FileReader(archivoTxt);
                BufferedReader br = new BufferedReader(fr);
                while ((line = br.readLine()) != null){
                    if (!line.isEmpty()){
                        txt += line + "\n";
                    }
                }

                if (!txt.isEmpty()){
                    String[] txtSplit = txt.split("\n");

                    for (int i=0; i<txtSplit.length; i++){
                        if ("Almacenes;".equals(txtSplit[i])){
                            i++;
                            while (!"Rutas;".equals(txtSplit[i])){
                                if (txtSplit[i].contains("Almacen") && txtSplit[i].contains(":")){
                                    String nombreAlmacen = txtSplit[i].replace("Almacen ", "").replace(":", "");
                                    i++;
                                    ListaProductos productos = new ListaProductos();
                                    while (!txtSplit[i].contains("Almacen") && !txtSplit[i].contains(":") && !txtSplit[i].contains("Rutas;")){
                                        String[] productoSplit = txtSplit[i].split(",");
                                        String nombreProducto = productoSplit[0];
                                        if (productoSplit[1].contains(";")){
                                            int cantidadProducto = Integer.parseInt(productoSplit[1].replace(";", ""));
                                            NodoProducto producto = new NodoProducto(nombreProducto, cantidadProducto);
                                            productos.agregarProductoFinal(producto);
                                        } else{
                                            int cantidadProducto = Integer.parseInt(productoSplit[1]);
                                            NodoProducto producto = new NodoProducto(nombreProducto, cantidadProducto);
                                            productos.agregarProductoFinal(producto);
                                        }
                                       
                                        i++;
                                    }
                                    NodoAlmacen almacen = new NodoAlmacen(nombreAlmacen, productos);
                                    almacenes.agregarAlmacenFinal(almacen);
                                    System.out.println(almacenes.imprimirAlmacen(nombreAlmacen));
                                }
                                    
                            }
                            
                        }
                        
                        if ("Rutas;".equals(txtSplit[i])){
                            i++;
                            while (i<txtSplit.length){
                                String[] rutaSplit = txtSplit[i].split(",");
                                String nombreAlmacen1 = rutaSplit[0];
                                String nombreAlmacen2 = rutaSplit[1];
                                int distancia = Integer.parseInt(rutaSplit[2]);
                                rutas.agregarRutaFinal(nombreAlmacen1, nombreAlmacen2, distancia);
                                i++;
                            
                            }
                        }
                    }
                    System.out.println(rutas.imprimirRutas(rutas));
                    
                    br.close();                    
                }
            } catch (Exception e){
                JOptionPane.showMessageDialog(null, "Archivo no compatible");
            }
        }
        return new GrupoListas(almacenes, rutas);
    }
}
